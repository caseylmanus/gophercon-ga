package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
)

func get() (string, error) {
	res, err := http.Get("https://google.com")
	if err != nil {
		return "", err
	}
	if res.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected status code %v", res.StatusCode)
	}
	defer res.Body.Close()
	bits, err := io.ReadAll(res.Body)
	if err != nil {
		return "", fmt.Errorf("error reading response body %v", err)
	}
	return string(bits), nil
}

func main() {
	s, err := get()
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	fmt.Println(s)
}

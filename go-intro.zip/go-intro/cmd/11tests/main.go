package main

import "fmt"

func main() {
	fmt.Println(SplitOnColon("Hello:Cruel:World"))
}

func SplitOnColon(s string) []string {
	parts := make([]string, 1)
	for i, p := 0, 0; i < len(s); i++ {
		if string(s[i]) != ":" {
			parts[p] = parts[p] + string(s[i])
		} else {
			parts = append(parts, "")
			p++
		}
	}
	return parts
}

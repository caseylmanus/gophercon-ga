package main

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSplitOnColon(t *testing.T) {
	require.True(t, len(SplitOnColon("Hello:Cruel")) == 2, "should be two parts")
	assert.ElementsMatch(t, []string{"Hello", "Cruel"}, SplitOnColon("Hello:Cruel"))
}

func TestSplitOnColonTable(t *testing.T) {
	cases := []struct {
		name   string
		in     string
		expect []string
	}{
		{
			name:   "no split",
			in:     "hi",
			expect: []string{"hi"},
		},
		{
			name:   "split empty",
			in:     "::::",
			expect: []string{"", "", "", "", ""},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			require.Equal(t, tc.expect, SplitOnColon(tc.in))
		})
	}
}

//fuzz testing

//benchmarking

//race conditions

package main

import (
	"fmt"
	"sync"
	"time"
)

func printNumbers(wg *sync.WaitGroup, start, end int) {
	defer wg.Done()
	for i := start; i < end; i++ {
		time.Sleep(100 * time.Millisecond)
		fmt.Println(i)
	}
}

func main() {
	var wg sync.WaitGroup
	wg.Add(2)

	go printNumbers(&wg, 0, 10)
	go printNumbers(&wg, 10, 20)

	wg.Wait()

	ch := LongProcess()
	fmt.Println(<-ch)
}

func LongProcess() chan string {
	ch := make(chan string)
	go func() {
		time.Sleep(time.Second)
		ch <- "I'm done"
		close(ch)
	}()
	return ch
}

package main

import (
	"encoding/json"
	"log"
	"net/http"
)

type Person struct {
	Name string `json:"name"`
	Age  int    `json:"age"`
}

func main() {
	// Create a new HTTP server.
	mux := http.NewServeMux()

	// Create a handler function that returns a JSON object.
	handler := func(w http.ResponseWriter, r *http.Request) {
		// Create a new Person object.
		person := Person{"Alice", 25}

		// Marshal the Person object to JSON.
		jsonBytes, err := json.Marshal(person)
		if err != nil {
			log.Fatal(err)
		}

		// Set the response header to indicate that the response is JSON.
		w.Header().Set("Content-Type", "application/json")

		// Write the JSON response to the client.
		w.Write(jsonBytes)
	}

	// Register the handler function with the server.
	mux.HandleFunc("/", handler)

	// Start the server.
	log.Fatal(http.ListenAndServe(":8080", mux))
}

package main

// Maintained precisely
const e = 2.71828182845904523536028747135266249775724709369995957496696763
const third = 1 / 3

// type declared or inferred
const M64 int64 = 1 << 20
const M = 1 << 20

// Evaluated at compile-time:
const big = 1 << 100 / 1e30 // valid constant expression

// grouping

const (
	name  = "Casey"
	title = "Principal Data Engineer"
)

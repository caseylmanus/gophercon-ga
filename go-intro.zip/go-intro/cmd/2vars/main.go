package main

import "fmt"

// Statically typed:
var (
	one string = "hello" //declared
	two        = 2       //determined at compile time
)

func ret() *int {
	//Short variable declaration (inside functions only):
	x := 42
	s, b := "foo", true
	// Can safely take address of _any_ variable!
	fmt.Println(s, b)
	return &x
}

package main

/* BUILT-IN
    ---------------------------------------------
	uint8 (byte), uint16, uint32, uint32, uint64,
	int8, int16, int32, int32 (rune), int64,
	float32, float64,
	complex64, complex128,
	uint, int, uintptr,
	bool, string,
	error  // not so usual

*/
/* Composite Types
---------------------------------
array, struct, pointer, function,
slice, map, channel
*/

/*
Interfaces
*/
func main() {

}

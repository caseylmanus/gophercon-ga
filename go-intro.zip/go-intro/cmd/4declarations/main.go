package main

// types might be other types
type Weekday int

// declaring a struct
type Point struct {
	x, y int
}

// functions are types
type WalkFunc func(file string) error

func WalkFiles(w WalkFunc) {
	//execute w() on each file
}

func main() {

}

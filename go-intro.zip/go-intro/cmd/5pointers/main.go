package main

import "fmt"

// Pass by pointer for mutability
// Pass by pointer when variable is large ([]byte)
// Pass by pointer when structural
// Copy is shallow copy

func main() {
	p := Person{First: "Casey", Last: "Manus"}
	noMod(p)
	fmt.Println(p)
	mod(&p)
	fmt.Println(p)
}

func noMod(p Person) {
	p.First = "Doesn't"
	p.Last = "Matter"
}

func mod(p *Person) {
	p.First = "Someone"
	p.Last = "Else"
}

type Person struct {
	First, Last string
}

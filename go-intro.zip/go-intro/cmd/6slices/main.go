package main

import "fmt"

// ConseptualSlice a slice can be thought of a struct roughly of this shape
type ConceptualSlice struct {
	array    *[8]int
	len, cap int
}

func main() {

	var list []int // a nil slice may append
	list = append(list, 1)
	cantAppendToSlice(list)
	fmt.Println(list)      // still has 1 element
	list = appendNew(list) // accept new slice
	fmt.Println(list)
	modify(list) //can modify elements
	fmt.Println(list)

	// declare a size of certain size (filled with zero values)
	sized := make([]int, 8)
	fmt.Println(sized, "sized slice")

	withCap := make([]int, 4, 8)
	fmt.Println(withCap, "sized with capacity")
	fmt.Println(len(withCap), fmt.Sprintf("%p", &withCap))
	withCap = append(withCap, 1, 2)
	fmt.Println(withCap, "same slice after append because it has capacity")
	fmt.Println(len(withCap), fmt.Sprintf("%p", &withCap))

	// iterating over slice
	for i, v := range withCap {
		fmt.Println(i, v)
	}

}

func cantAppendToSlice(l []int) {
	l = append(l, 2)
}
func appendNew(l []int) []int { // typical pattern
	return append(l, 2)
}
func modify(l []int) {
	l[1] = 3 //underlying array can be modified because it's referenced by pointer
}

package main

import "fmt"

func main() {
	var population map[string]int
	//unlike slices maps must be initialized
	population = map[string]int{
		"cleveland": 100000,
		"miami":     2300000,
		"new york":  30232303,
	}
	// iteration order randomized
	for k, v := range population {
		fmt.Println(k, v)
	}
	//assign
	population["miami"] = 1
	fmt.Println(population["miami"]) //lookup cost O(1)
	//append
	population["la"] = 22000000
	fmt.Println(population)

}

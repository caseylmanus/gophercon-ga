package main

import "fmt"

func main() {
	p := Person{First: "Casey", Last: "Manus"}
	p.Greet()
	p.UpdateName()
	p.Greet()
	//first class values
	getFunc()()
}

func addOne(i int) int {
	return i + 1
}

// variadic arguments (must be last arg)
func sum(i ...int) int {
	var total int
	for _, x := range i {
		total = total + x
	}
	return total
}

func sumToTen() {
	x := sum(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
	fmt.Println(x)
}

func greeter() (string, string) {
	return "hello", "world"
}

func callGreeter() {
	fmt.Println(greeter())
}

type Person struct {
	First, Last string
}

// method
func (p Person) Greet() {
	fmt.Println("Hello from", p.First, p.Last)
}

// pointer reciever
func (p *Person) UpdateName() {
	p.First = "Something"
}

func getFunc() func() {
	return callGreeter
}

package main

import "fmt"

func main() {
	p := Person{First: "Casey", Last: "Manus"}
	do(p)
}

func do(p Printer) {
	fmt.Println(p.Print())
}

type Printer interface {
	Print() string
}

type Person struct {
	First, Last string
}

func (p Person) Print() string {
	return p.Last + ", " + p.First
}

// declare interface at the reciever
// don't premptively declare interfaces for others to use

// make interfaces small and composable
type Reader interface {
	Read() string
}
type Writer interface {
	Write(string)
}
type ReadWriter interface {
	Reader
	Writer
}
